package com.englishclassroom.app.data

import android.content.Context
import com.englishclassroom.app.model.User

class UserPreferences(context: Context) {
    private val prefs = context.getSharedPreferences("english_classroom_prefs", Context.MODE_PRIVATE)

    fun getUser(): User? {
        val id = prefs.getString("user_id", null) ?: return null
        val name = prefs.getString("user_name", "") ?: ""
        val role = prefs.getString("user_role", "student") ?: "student"
        val code = prefs.getString("user_code", "") ?: ""
        return User(id = id, name = name, role = role, classCode = code)
    }

    fun saveUser(user: User) {
        prefs.edit()
            .putString("user_id", user.id)
            .putString("user_name", user.name)
            .putString("user_role", user.role)
            .putString("user_code", user.classCode)
            .apply()
    }

    fun clear() {
        prefs.edit().clear().apply()
    }
}
