package com.englishclassroom.app.data

import com.englishclassroom.app.model.ChatMessage
import com.englishclassroom.app.model.DailySummary
import com.englishclassroom.app.model.Quiz
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {
    private val firestore = FirebaseFirestore.getInstance()

    // Real-time messages stream
    fun getMessagesFlow(): Flow<List<ChatMessage>> = callbackFlow {
        val listener: ListenerRegistration = firestore.collection("messages")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val messages = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(ChatMessage::class.java)?.copy(id = doc.id)
                }?.sortedBy { it.createdAtTimestamp } ?: emptyList()

                trySend(messages)
            }
        awaitClose { listener.remove() }
    }

    // Send chat message
    suspend fun sendMessage(message: ChatMessage) {
        val map = hashMapOf(
            "id" to message.id,
            "senderId" to message.senderId,
            "senderName" to message.senderName,
            "senderRole" to message.senderRole,
            "text" to message.text,
            "timestamp" to message.timestamp,
            "date" to message.date,
            "isTeacherMention" to message.isTeacherMention,
            "createdAtTimestamp" to System.currentTimeMillis()
        )
        firestore.collection("messages").document(message.id).set(map).await()
    }

    // Teacher Freeze Flow
    fun getChatFreezeFlow(): Flow<Boolean> = callbackFlow {
        val listener = firestore.collection("settings").document("chat")
            .addSnapshotListener { snapshot, _ ->
                val isPaused = snapshot?.getBoolean("isPaused") ?: false
                trySend(isPaused)
            }
        awaitClose { listener.remove() }
    }

    suspend fun setChatFreeze(isPaused: Boolean) {
        val map = hashMapOf(
            "isPaused" to isPaused,
            "updatedAt" to System.currentTimeMillis()
        )
        firestore.collection("settings").document("chat").set(map).await()
    }

    // Real-time Quizzes Flow
    fun getQuizzesFlow(): Flow<List<Quiz>> = callbackFlow {
        val listener = firestore.collection("quizzes")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val quizzes = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Quiz::class.java)?.copy(id = doc.id)
                }?.sortedByDescending { it.createdAtTimestamp } ?: emptyList()

                trySend(quizzes)
            }
        awaitClose { listener.remove() }
    }

    suspend fun addQuiz(quiz: Quiz) {
        firestore.collection("quizzes").document(quiz.id).set(quiz).await()
    }

    // Real-time Summaries Flow
    fun getSummariesFlow(): Flow<List<DailySummary>> = callbackFlow {
        val listener = firestore.collection("summaries")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                val summaries = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(DailySummary::class.java)?.copy(id = doc.id)
                }?.sortedByDescending { it.createdAtTimestamp } ?: emptyList()

                trySend(summaries)
            }
        awaitClose { listener.remove() }
    }

    suspend fun addSummary(summary: DailySummary) {
        firestore.collection("summaries").document(summary.id).set(summary).await()
    }
}
