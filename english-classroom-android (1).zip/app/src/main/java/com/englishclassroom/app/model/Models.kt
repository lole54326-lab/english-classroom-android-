package com.englishclassroom.app.model

data class User(
    val id: String = "",
    val name: String = "",
    val role: String = "student", // "student" or "teacher"
    val classCode: String = ""
)

data class ChatMessage(
    val id: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val senderRole: String = "student",
    val text: String = "",
    val timestamp: String = "",
    val date: String = "",
    val isTeacherMention: Boolean = false,
    val createdAtTimestamp: Long = 0L
)

data class QuizQuestion(
    val id: String = "",
    val type: String = "multiple_choice",
    val question: String = "",
    val options: List<String> = emptyList(),
    val correctAnswer: String = "",
    val explanation: String = ""
)

data class Quiz(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val creatorName: String = "",
    val creatorRole: String = "teacher",
    val createdAt: String = "",
    val createdAtTimestamp: Long = 0L,
    val questions: List<QuizQuestion> = emptyList()
)

data class DailySummary(
    val id: String = "",
    val date: String = "",
    val title: String = "",
    val topicsCovered: List<String> = emptyList(),
    val homework: String = "",
    val absenteeNotes: String = "",
    val authorName: String = "",
    val authorRole: String = "teacher",
    val createdAt: String = "",
    val createdAtTimestamp: Long = 0L
)
