package com.englishclassroom.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.DisableSelection
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.englishclassroom.app.data.FirebaseRepository
import com.englishclassroom.app.model.ChatMessage
import com.englishclassroom.app.model.User
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ChatScreen(user: User, repository: FirebaseRepository) {
    val messages by repository.getMessagesFlow().collectAsState(initial = emptyList())
    val isChatPaused by repository.getChatFreezeFlow().collectAsState(initial = false)
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    var textInput by remember { mutableStateOf("") }
    var arabicWarning by remember { mutableStateOf<String?>(null) }

    fun hasArabic(text: String): Boolean {
        val arabicRegex = Regex("[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]")
        return arabicRegex.containsMatchIn(text)
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val isInputBlocked = isChatPaused && user.role != "teacher"

    Scaffold(
        topBar = {
            Surface(
                color = Color.White,
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "English Chatroom",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.Black
                        )
                        Text(
                            text = if (isChatPaused) "Chat Paused by Teacher" else "Live • English Only",
                            fontSize = 11.sp,
                            color = if (isChatPaused) Color.Red else Color(0xFF16A34A)
                        )
                    }

                    if (user.role == "teacher") {
                        Button(
                            onClick = {
                                scope.launch {
                                    repository.setChatFreeze(!isChatPaused)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isChatPaused) Color(0xFFDC2626) else Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (isChatPaused) Icons.Default.Lock else Icons.Default.LockOpen,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (isChatPaused) "Resume" else "Freeze",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(8.dp)
            ) {
                arabicWarning?.let {
                    Text(
                        text = it,
                        color = Color.Red,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 12.dp, bottom = 4.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Ask Teacher Button (Red Circle)
                    Button(
                        onClick = {
                            if (!isInputBlocked) {
                                textInput = "@Teacher: "
                            }
                        },
                        shape = CircleShape,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Text(text = "Ask", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = textInput,
                        onValueChange = {
                            textInput = it
                            if (hasArabic(it)) {
                                arabicWarning = "English only! Arabic characters are not allowed."
                            } else {
                                arabicWarning = null
                            }
                        },
                        placeholder = {
                            Text(
                                text = if (isInputBlocked) "Teacher paused chat..." else "Type in English...",
                                fontSize = 13.sp
                            )
                        },
                        enabled = !isInputBlocked,
                        singleLine = true,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(24.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = {
                            val content = textInput.trim()
                            if (content.isEmpty() || hasArabic(content)) return@IconButton

                            val timeFormat = SimpleDateFormat("h:mm a", Locale.US)
                            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                            val now = Date()

                            val msg = ChatMessage(
                                id = UUID.randomUUID().toString(),
                                senderId = user.id,
                                senderName = user.name,
                                senderRole = user.role,
                                text = content,
                                timestamp = timeFormat.format(now),
                                date = dateFormat.format(now),
                                isTeacherMention = content.contains("@Teacher", ignoreCase = true)
                            )

                            scope.launch {
                                repository.sendMessage(msg)
                            }
                            textInput = ""
                        },
                        enabled = !isInputBlocked && textInput.isNotBlank() && !hasArabic(textInput),
                        modifier = Modifier
                            .size(40.dp)
                            .background(
                                if (!isInputBlocked && textInput.isNotBlank() && !hasArabic(textInput)) Color.Black else Color.LightGray,
                                CircleShape
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        // DisableSelection to prevent text copying
        DisableSelection {
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8F8F8))
                    .padding(innerPadding)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    val isMe = message.senderId == user.id

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = if (isMe) Alignment.End else Alignment.Start
                    ) {
                        Text(
                            text = "${message.senderName} (${if (message.senderRole == "teacher") "Teacher" else "Student"})",
                            fontSize = 10.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )

                        Box(
                            modifier = Modifier
                                .widthIn(max = 280.dp)
                                .background(
                                    when {
                                        message.isTeacherMention -> Color(0xFFFEF2F2)
                                        isMe -> Color(0xFFDCFCE7) // Soft Green for user
                                        else -> Color.White // White for others
                                    },
                                    RoundedCornerShape(14.dp)
                                )
                                .border(
                                    1.dp,
                                    if (message.isTeacherMention) Color(0xFFF87171) else Color(0xFFE5E7EB),
                                    RoundedCornerShape(14.dp)
                                )
                                .padding(12.dp)
                        ) {
                            Column {
                                if (message.isTeacherMention) {
                                    Text(
                                        text = "QUESTION FOR TEACHER",
                                        color = Color(0xFFDC2626),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                }
                                Text(
                                    text = message.text,
                                    color = Color.Black,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Normal
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = message.timestamp,
                                    color = Color.Gray,
                                    fontSize = 9.sp,
                                    modifier = Modifier.align(Alignment.End)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
