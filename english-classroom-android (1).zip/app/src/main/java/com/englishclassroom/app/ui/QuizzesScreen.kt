package com.englishclassroom.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.englishclassroom.app.data.FirebaseRepository
import com.englishclassroom.app.model.Quiz
import com.englishclassroom.app.model.User

@Composable
fun QuizzesScreen(user: User, repository: FirebaseRepository) {
    val quizzes by repository.getQuizzesFlow().collectAsState(initial = emptyList())
    var activeQuiz by remember { mutableStateOf<Quiz?>(null) }

    if (activeQuiz != null) {
        QuizTakerScreen(quiz = activeQuiz!!, onBack = { activeQuiz = null })
    } else {
        Scaffold(
            topBar = {
                Surface(color = Color.White, shadowElevation = 2.dp) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "English Quizzes",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF8F8F8))
                    .padding(padding)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (quizzes.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No quizzes posted yet.",
                                color = Color.Gray,
                                fontSize = 13.sp
                            )
                        }
                    }
                }

                items(quizzes, key = { it.id }) { quiz ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { activeQuiz = quiz },
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = quiz.title,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.Black
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = quiz.description,
                                fontSize = 12.sp,
                                color = Color.DarkGray
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${quiz.questions.size} Questions",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Button(
                                    onClick = { activeQuiz = quiz },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Text(text = "Start Quiz", fontSize = 12.sp, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuizTakerScreen(quiz: Quiz, onBack: () -> Unit) {
    val answers = remember { mutableStateMapOf<String, String>() }
    var isSubmitted by remember { mutableStateOf(false) }

    val score = remember(isSubmitted) {
        if (!isSubmitted) 0
        else quiz.questions.count { answers[it.id]?.trim()?.equals(it.correctAnswer.trim(), ignoreCase = true) == true }
    }

    Scaffold(
        topBar = {
            Surface(color = Color.White, shadowElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onBack) {
                        Text(text = "Back", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                    Text(
                        text = quiz.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = Color.Black
                    )
                    Text(text = "${answers.size}/${quiz.questions.size}", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF8F8F8))
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (isSubmitted) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(text = "Quiz Completed!", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Score: $score / ${quiz.questions.size}",
                                color = Color(0xFF4ADE80),
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            items(quiz.questions.withIndex().toList()) { (index, q) ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Question ${index + 1}: ${q.question}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        q.options.forEach { opt ->
                            val isSelected = answers[q.id] == opt
                            val isCorrect = opt.equals(q.correctAnswer, ignoreCase = true)

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .background(
                                        when {
                                            isSubmitted && isCorrect -> Color(0xFFDCFCE7)
                                            isSubmitted && isSelected && !isCorrect -> Color(0xFFFEE2E2)
                                            isSelected -> Color.Black
                                            else -> Color(0xFFF4F4F5)
                                        },
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable(enabled = !isSubmitted) {
                                        answers[q.id] = opt
                                    }
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = opt,
                                    color = if (isSelected && !isSubmitted) Color.White else Color.Black,
                                    fontSize = 13.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }

                        if (isSubmitted) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Correct Answer: ${q.correctAnswer}",
                                color = Color(0xFF16A34A),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            if (q.explanation.isNotBlank()) {
                                Text(
                                    text = q.explanation,
                                    color = Color.DarkGray,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            if (!isSubmitted) {
                item {
                    Button(
                        onClick = { isSubmitted = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                    ) {
                        Text(text = "Submit Answers", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
