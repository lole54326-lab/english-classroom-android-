package com.englishclassroom.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.englishclassroom.app.model.User
import java.util.UUID

@Composable
fun LoginScreen(onLoginSuccess: (User) -> Unit) {
    var name by remember { mutableStateOf("") }
    var classCode by remember { mutableStateOf("ENG101") }
    var role by remember { mutableStateOf("student") }
    var error by remember { mutableStateOf<String?>(null) }

    fun hasArabic(text: String): Boolean {
        val arabicRegex = Regex("[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]")
        return arabicRegex.containsMatchIn(text)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Welcome to Classroom",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Text(
                text = "Enter your English name to join live chat",
                fontSize = 13.sp,
                color = Color.DarkGray
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Role Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF4F4F5), RoundedCornerShape(12.dp))
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (role == "student") Color.Black else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { role = "student" }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Student",
                        color = if (role == "student") Color.White else Color.Black,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (role == "teacher") Color.Black else Color.Transparent,
                            RoundedCornerShape(8.dp)
                        )
                        .clickable { role = "teacher" }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Teacher",
                        color = if (role == "teacher") Color.White else Color.Black,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = name,
                onValueChange = {
                    name = it
                    if (hasArabic(it)) {
                        error = "Arabic letters not allowed! Use English alphabet only."
                    } else {
                        error = null
                    }
                },
                label = { Text("Your English Name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = classCode,
                onValueChange = { classCode = it },
                label = { Text("Class Code") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            error?.let {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = it, color = Color.Red, fontSize = 12.sp)
            }

            Spacer(modifier = Modifier.height(24.dp))

            Button(
                onClick = {
                    if (name.trim().isEmpty()) {
                        error = "Please enter your name."
                        return@Button
                    }
                    if (hasArabic(name)) {
                        error = "Only English names are permitted."
                        return@Button
                    }
                    val user = User(
                        id = UUID.randomUUID().toString(),
                        name = name.trim(),
                        role = role,
                        classCode = classCode.trim()
                    )
                    onLoginSuccess(user)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
            ) {
                Text(text = "Join Classroom", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}
